package acc.br.servenccbank

enum class UsuarioRole {
    ADMIN,USUARIO
}