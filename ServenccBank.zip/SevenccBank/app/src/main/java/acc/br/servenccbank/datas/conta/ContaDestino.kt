package acc.br.servenccbank.datas.conta

data class ContaDestino(
    val clienteDestino : ClienteDestinoResponse
)

