package acc.br.servenccbank.datas.transacao

import java.math.BigDecimal

data class TransacaoRequest(
    val valor : BigDecimal
)
