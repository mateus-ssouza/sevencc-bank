package acc.br.servenccbank

enum class TipoConta {
    CORRENTE,POUPANCA
}