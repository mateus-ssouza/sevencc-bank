package acc.br.servenccbank.datas.conta

import acc.br.servenccbank.TipoConta
import acc.br.servenccbank.datas.transacao.Tipo
import java.math.BigDecimal

data class ContaResponse(
    val id : Long,
    val numero: Long,
    val saldo : BigDecimal,
    val tipo : TipoConta,
    val agencia : AgenciaResponse,
    val cliente : ClienteResponse
)
