package acc.br.servenccbank

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class PerfilActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.perfil_activity)
        val btnDdPessoais: Button = findViewById(R.id.btnDdPessoais)
        val btnDdConta: Button = findViewById(R.id.btnDdConta)

        btnDdPessoais.setOnClickListener {
            val intent = Intent(this, DadosPessoaisActivity::class.java)
            startActivity(intent)
        }
        btnDdConta.setOnClickListener {
            val intent = Intent(this, DadosContaActivity::class.java)
            startActivity(intent)
        }
    }
}
