package acc.br.servenccbank.datas.conta

import acc.br.servenccbank.TipoConta

data class ContaRequest(
    val numeroDaAgencia : Long,
    val tipo : TipoConta
)
