package acc.br.servenccbank

import acc.br.servenccbank.datas.conta.TransacoesContaResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ExtratoActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var listViewExtrato: ListView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.extrato_activity)

        progressBar = findViewById(R.id.progressBar)
        listViewExtrato = findViewById(R.id.listViewExtrato)

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        listViewExtrato.adapter = adapter

        // Recuperar o token JWT das SharedPreferences
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("JWT_TOKEN", null)

        if (token != null) {
            progressBar.visibility = ProgressBar.VISIBLE
            listViewExtrato.visibility = ListView.GONE
            val apiService = APIClient.instance.create(BankAPI::class.java)
            val call = apiService.getExtrato("Bearer $token")

            call.enqueue(object : Callback<List<TransacoesContaResponse>> {
                override fun onResponse(
                    call: Call<List<TransacoesContaResponse>>,
                    response: Response<List<TransacoesContaResponse>>
                ) {
                    progressBar.visibility = ProgressBar.GONE
                    listViewExtrato.visibility = ListView.VISIBLE

                    if (response.isSuccessful) {
                        val transacoes = response.body()
                        if (transacoes != null) {
                            val listaTransacoes = transacoes.map {
                                "Valor: ${it.valor}, Tipo: ${it.tipo}, Data: ${it.dataTransacao}"
                            }

                            adapter.clear()
                            adapter.addAll(listaTransacoes)
                            adapter.notifyDataSetChanged()
                        } else {
                            Toast.makeText(this@ExtratoActivity, "Nenhuma transação encontrada", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@ExtratoActivity, "Falha ao carregar extrato: ${response.code()}", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<List<TransacoesContaResponse>>, t: Throwable) {
                    // Ocultar o ProgressBar e mostrar o ListView
                    progressBar.visibility = ProgressBar.GONE
                    listViewExtrato.visibility = ListView.VISIBLE

                    Toast.makeText(this@ExtratoActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "Token não encontrado. Faça login novamente.", Toast.LENGTH_SHORT).show()
        }
    }
}
