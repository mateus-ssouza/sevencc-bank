package acc.br.servenccbank

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // Defina o layout correto

        drawerLayout = findViewById(R.id.drawer_layout)
        // Configuração dos botões para redirecionar para as atividades correspondentes
        val btnMenu: FloatingActionButton = findViewById(R.id.btnMenu)
        btnMenu.setOnClickListener {
            drawerLayout.openDrawer(GravityCompat.START)
        }
        val btnExtrato: FloatingActionButton = findViewById(R.id.bntExtrato)
        btnExtrato.setOnClickListener {
            val intent = Intent(this, ExtratoActivity::class.java)
            startActivity(intent)
        }

        val btnTransferir: FloatingActionButton = findViewById(R.id.bntTransfer)
        btnTransferir.setOnClickListener {
            val intent = Intent(this, TransferirActivity::class.java)
            startActivity(intent)
        }
        val btnCriarConta: FloatingActionButton = findViewById(R.id.bntCriarConta)
        btnCriarConta.setOnClickListener {
            val intent = Intent(this, CriarContaActivity::class.java)
            startActivity(intent)
        }

        // Configuração do NavigationView
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_perfil -> {
                    val intent = Intent(this, PerfilActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_config -> {
                    val intent = Intent(this, ConfigureActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_suport -> {
                    val intent = Intent(this, SuporteActivity::class.java)
                    startActivity(intent)
                }
                R.id.nav_help -> {
                    val intent = Intent(this, AjudaActivity::class.java)
                    startActivity(intent)
                }
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
