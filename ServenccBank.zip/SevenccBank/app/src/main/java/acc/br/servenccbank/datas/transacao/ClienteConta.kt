package acc.br.servenccbank.datas.transacao

data class ClienteConta(
    val nome: String,
    val cpf: String
)
