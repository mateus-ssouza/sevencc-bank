package acc.br.servenccbank.datas.transacao

import java.math.BigDecimal

data class TransferenciaRequestDTO(
    val valor: BigDecimal,
    val numeroContaDestino: Long
)
