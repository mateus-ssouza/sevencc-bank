package acc.br.servenccbank.datas.transacao

data class ContaTransacao(
    val numero: Long,
    val cliente: ClienteConta
)
