package acc.br.servenccbank.datas.conta

import java.math.BigDecimal
import acc.br.servenccbank.datas.transacao.Tipo
import java.util.Optional

data class TransacoesContaResponse(
    val valor: BigDecimal,
    val tipo: Tipo,
    val dataTransacao: String,
    val contaDestino: ContaDestino?
)

