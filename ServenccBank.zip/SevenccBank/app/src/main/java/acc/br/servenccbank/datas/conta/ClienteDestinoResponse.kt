package acc.br.servenccbank.datas.conta

data class ClienteDestinoResponse(
    val nome: String,
    val cpf: String
)
