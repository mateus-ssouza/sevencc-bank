package acc.br.servenccbank

import acc.br.servenccbank.datas.conta.ContaResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Context
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DadosContaActivity : AppCompatActivity() {

    private lateinit var txtNumeroConta: TextView
    private lateinit var txtSaldo: TextView
    private lateinit var txtTipoConta: TextView
    private lateinit var txtAgenciaNome: TextView
    private lateinit var txtAgenciaNumero: TextView
    private lateinit var txtClienteNome: TextView
    private lateinit var txtClienteCpf: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dados_conta_activity)

        txtNumeroConta = findViewById(R.id.txtNumeroConta)
        txtSaldo = findViewById(R.id.txtSaldo)
        txtTipoConta = findViewById(R.id.txtTipoConta)
        txtAgenciaNome = findViewById(R.id.txtAgenciaNome)
        txtAgenciaNumero = findViewById(R.id.txtAgenciaNumero)
        txtClienteNome = findViewById(R.id.txtClienteNome)
        txtClienteCpf = findViewById(R.id.txtClienteCpf)

        // Recuperar o token JWT das SharedPreferences
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("JWT_TOKEN", null)

        if (token != null) {
            val apiService = APIClient.instance.create(BankAPI::class.java)
            val call = apiService.getContaDetails("Bearer $token")

            call.enqueue(object : Callback<ContaResponse> {
                override fun onResponse(
                    call: Call<ContaResponse>,
                    response: Response<ContaResponse>
                ) {
                    if (response.isSuccessful) {
                        val conta = response.body()
                        if (conta != null) {
                            // Preenchendo as informações da conta
                            txtNumeroConta.text = conta.numero.toString()
                            txtSaldo.text = conta.saldo.toString()
                            txtTipoConta.text = conta.tipo.toString()
                            txtAgenciaNome.text = conta.agencia.nome
                            txtAgenciaNumero.text = conta.agencia.numero.toString()
                            txtClienteNome.text = conta.cliente.nome
                            txtClienteCpf.text = conta.cliente.cpf
                        }
                    } else {
                        Toast.makeText(this@DadosContaActivity, "Falha ao carregar os detalhes da conta: ${response.code()}", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<ContaResponse>, t: Throwable) {
                    Toast.makeText(this@DadosContaActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "Token não encontrado. Faça login novamente.", Toast.LENGTH_SHORT).show()
        }
    }
}
