package acc.br.servenccbank.datas

data class LoginResponse(
    val token: String
)
