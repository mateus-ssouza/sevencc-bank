package acc.br.servenccbank

import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import acc.br.servenccbank.datas.CadastroRequest
import acc.br.servenccbank.datas.EnderecoRequest
import acc.br.servenccbank.datas.CadastroResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Intent
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class CadastroActivity : AppCompatActivity() {

    private lateinit var edtUser: EditText
    private lateinit var edtData: EditText
    private lateinit var edtSenha: EditText
    private lateinit var edtCpf: EditText
    private lateinit var edtFone: EditText
    private lateinit var edtEmail: EditText
    private lateinit var edtCep: EditText
    private lateinit var edtRua: EditText
    private lateinit var edtNumero: EditText
    private lateinit var edtBairro: EditText
    private lateinit var edtCidade: EditText
    private lateinit var edtEstado: EditText
    private lateinit var edtPais: EditText
    private lateinit var btnCadastrado: Button

    private val apiClient: BankAPI by lazy {
        APIClient.instance.create(BankAPI::class.java)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.cadastro_activity)

        edtUser = findViewById(R.id.edtUser)
        edtData = findViewById(R.id.edtData)
        edtSenha = findViewById(R.id.edtSenha)
        edtFone = findViewById(R.id.edtFone)
        edtEmail = findViewById(R.id.edtEmail)
        edtCpf = findViewById(R.id.edtCpf)
        edtCep = findViewById(R.id.edtCep)
        edtRua = findViewById(R.id.edtRua)
        edtNumero = findViewById(R.id.edtNumero)
        edtBairro = findViewById(R.id.edtBairro)
        edtCidade = findViewById(R.id.edtCidade)
        edtEstado = findViewById(R.id.edtEstado)
        edtPais = findViewById(R.id.edtPais)
        btnCadastrado = findViewById(R.id.btnCadastrado)

        btnCadastrado.setOnClickListener {
            if (validateFields()) {
                val cadastroRequest = CadastroRequest(
                    nome = edtUser.text.toString(),
                    cpf = edtCpf.text.toString(),
                    telefone = edtFone.text.toString(),
                    dataNascimento = edtData.text.toString(),
                    email = edtEmail.text.toString(),
                    login = edtUser.text.toString(),
                    password = edtSenha.text.toString(),
                    endereco = EnderecoRequest(
                        cep = edtCep.text.toString(),
                        rua = edtRua.text.toString(),
                        numero = edtNumero.text.toString(),
                        bairro = edtBairro.text.toString(),
                        cidade = edtCidade.text.toString(),
                        estado = edtEstado.text.toString(),
                        pais = edtPais.text.toString()
                    )
                )

                apiClient.cadastrar(cadastroRequest).enqueue(object : Callback<CadastroResponse> {
                    override fun onResponse(call: Call<CadastroResponse>, response: Response<CadastroResponse>) {
                        if (response.isSuccessful) {
                            Toast.makeText(this@CadastroActivity, "Cliente cadastrado com sucesso!", Toast.LENGTH_SHORT).show()
                            val intent = Intent(this@CadastroActivity, TelaInicialActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this@CadastroActivity, "Erro ao cadastrar cliente.", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<CadastroResponse>, t: Throwable) {
                        Toast.makeText(this@CadastroActivity, "Erro na comunicação com o servidor.", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
    }

    private fun validateFields(): Boolean {
        var isValid = true

        if (!isValidUser(edtUser.text.toString())) {
            edtUser.error = "Nome de usuário inválido"
            isValid = false
        }
        if (!isValidDate(edtData.text.toString())) {
            edtData.error = "Data de nascimento inválida"
            isValid = false
        }
        if (!isValidCpf(edtCpf.text.toString())) {
            edtData.error = "CPF inválida"
            isValid = false
        }
        if (!isValidPassword(edtSenha.text.toString())) {
            edtSenha.error = "Senha inválida"
            isValid = false
        }
        if (!isValidEmail(edtEmail.text.toString())) {
            edtEmail.error = "Email inválido"
            isValid = false
        }
        if (!isValidPhoneNumber(edtFone.text.toString())) {
            edtCep.error = "Telefone inválido"
            isValid = false
        }
        if (!isValidCep(edtCep.text.toString())) {
            edtCep.error = "CEP inválido"
            isValid = false
        }
        if (!isValidAddress(
                edtRua.text.toString(),
                edtNumero.text.toString(),
                edtBairro.text.toString(),
                edtCidade.text.toString(),
                edtEstado.text.toString(),
                edtPais.text.toString()
            )
        ) {

            isValid = false
        }

        return isValid
    }
//Validações das regras de negocios
    private fun isValidUser(user: String): Boolean {
        return user.length in 3..60
    }

    private fun isValidDate(date: String): Boolean {
        return try {
            LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            true
        } catch (e: Exception) {
            false
        }
    }
    private fun isValidCpf(cpf: String): Boolean {
        return cpf.length == 11 && cpf.all { it.isDigit() }
    }

    private fun isValidPassword(password: String): Boolean {
        return password.length in 6..25
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }
    private fun isValidPhoneNumber(phone: String): Boolean {
        return phone.length in 10..13 && phone.all { it.isDigit() }
    }
    private fun isValidCep(cep: String): Boolean {
        return cep.length == 8 && cep.all { it.isDigit() }
    }

    private fun isValidAddress(rua: String, numero: String, bairro: String, cidade: String, estado: String, pais: String): Boolean {
        return rua.length in 3..60 && numero.isNotBlank() && bairro.length in 3..50 && cidade.length in 3..50 && estado.length in 2..60 && pais.length in 2..60
    }
}
