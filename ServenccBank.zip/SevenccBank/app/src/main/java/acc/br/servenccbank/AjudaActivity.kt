package acc.br.servenccbank

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AjudaActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ajuda_activity)
    }
}
