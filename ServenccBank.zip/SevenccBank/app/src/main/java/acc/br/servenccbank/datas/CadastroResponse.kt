package acc.br.servenccbank.datas

import acc.br.servenccbank.UsuarioRole
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

data class CadastroResponse(
    val id: Long,
    val nome: String,
    val cpf: String,
    val dataNascimento: String,
    val telefone: String,
    val email: String,
    val dataCadastro: String,
    val login: String,
    val role: UsuarioRole,
    val endereco: EnderecoRequest
)
