package acc.br.servenccbank.interfaces
import acc.br.servenccbank.datas.CadastroRequest
import acc.br.servenccbank.datas.CadastroResponse
import acc.br.servenccbank.datas.LoginRequest
import acc.br.servenccbank.datas.LoginResponse
import acc.br.servenccbank.datas.conta.ContaRequest
import acc.br.servenccbank.datas.conta.ContaResponse
import acc.br.servenccbank.datas.conta.TransacoesContaResponse
import acc.br.servenccbank.datas.transacao.TransacaoResponseDTO
import acc.br.servenccbank.datas.transacao.TransferenciaRequestDTO
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST

interface BankAPI {

    @POST("auth/login")
    fun login(
        @Body request: LoginRequest): Call<LoginResponse>

    @POST("auth/register")
    fun cadastrar(
        @Body request: CadastroRequest): Call<CadastroResponse>

    @POST("transacao/transferir")
    fun transferir(
        @Header("Authorization") authHeader: String,
        @Body transferenciaRequestDTO: TransferenciaRequestDTO): Call<TransacaoResponseDTO>

    @GET("conta/extrato")
    fun getExtrato(
        @Header("Authorization") authHeader: String): Call<List<TransacoesContaResponse>>

    @POST("conta")
    fun createConta(
        @Header("Authorization") authHeader: String,
        @Body contaRequest: ContaRequest): Call<ContaResponse>
    @GET("conta/minha-conta")
    fun getContaDetails(
        @Header("Authorization") authHeader: String): Call<ContaResponse>
    @GET("cliente/meu-perfil")
    fun getPerfil(
        @Header("Authorization") authHeader: String): Call<CadastroResponse>
}