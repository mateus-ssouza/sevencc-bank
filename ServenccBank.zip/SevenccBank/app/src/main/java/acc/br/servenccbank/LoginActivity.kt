package acc.br.servenccbank

import acc.br.servenccbank.datas.LoginRequest
import acc.br.servenccbank.datas.LoginResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login_activity)

        val edtUser: EditText = findViewById(R.id.edtData)
        val edtSenha: EditText = findViewById(R.id.edtSenha)
        val btnAcesso: Button = findViewById(R.id.btnAcesso)

        btnAcesso.setOnClickListener {
            val usuario = edtUser.text.toString()
            val senha = edtSenha.text.toString()

            if (usuario.isNotEmpty() && senha.isNotEmpty()) {
                val authService = APIClient.instance.create(BankAPI::class.java)
                val loginRequest = LoginRequest(usuario, senha)

                authService.login(loginRequest).enqueue(object : Callback<LoginResponse> {
                    override fun onResponse(call: Call<LoginResponse>, response: Response<LoginResponse>) {
                        if (response.isSuccessful) {
                            // Armazenando o token para uso posterior
                            val token = response.body()?.token
                            if (token != null) {
                                val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
                                with(sharedPreferences.edit()) {
                                    putString("JWT_TOKEN", token)
                                    apply()
                                }
                            }
                            val intent = Intent(this@LoginActivity, MainActivity::class.java)
                            startActivity(intent)
                            finish()
                        } else {
                            Toast.makeText(this@LoginActivity, "Login falhou", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                        Toast.makeText(this@LoginActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                    }
                })
            } else {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
