package acc.br.servenccbank.datas.transacao

import java.math.BigDecimal
import java.util.Optional

data class TransacaoResponseDTO(
    val id: Long,
    val valor: BigDecimal,
    val tipo: Tipo,
    val dataTransacao: String,
    val contaOrigem: ContaTransacao,
    val contaDestino: ContaTransacao
)
