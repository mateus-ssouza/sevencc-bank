package acc.br.servenccbank.datas.transacao

enum class Tipo {
    DEPOSITO, SAQUE, TRANSFERENCIA
}
