package acc.br.servenccbank.datas

data class LoginRequest(
    val login: String,
    val password: String
)
