package acc.br.servenccbank.datas

data class CadastroRequest(
    val nome: String,
    val cpf: String,
    val telefone: String,
    val dataNascimento: String,
    val email: String,
    val login: String,
    val password: String,
    val endereco: EnderecoRequest

)
