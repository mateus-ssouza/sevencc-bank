package acc.br.servenccbank

import acc.br.servenccbank.datas.transacao.TransferenciaRequestDTO
import acc.br.servenccbank.datas.transacao.TransacaoResponseDTO
import acc.br.servenccbank.interfaces.BankAPI
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.math.BigDecimal
import android.content.Context


class TransferirActivity : AppCompatActivity() {

    private lateinit var edtNumConta: EditText
    private lateinit var edtValor: EditText
    private lateinit var btnTransferir: Button
    private lateinit var bankAPI: BankAPI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.transferir_activity)

        edtNumConta = findViewById(R.id.edtNumConta)
        edtValor = findViewById(R.id.edtValor)
        btnTransferir = findViewById(R.id.btnTransferir)

        bankAPI = APIClient.instance.create(BankAPI::class.java)

        btnTransferir.setOnClickListener {
            val numeroContaDestino = edtNumConta.text.toString().toLongOrNull()
            val valor = edtValor.text.toString().toBigDecimalOrNull()

            if (numeroContaDestino != null && valor != null) {
                transferir(valor, numeroContaDestino)
            } else {
                Toast.makeText(this, "Por favor, insira um número de conta e valor válidos", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun transferir(valor: BigDecimal, numeroContaDestino: Long) {
        val transferenciaRequest = TransferenciaRequestDTO(valor, numeroContaDestino)

        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("JWT_TOKEN", null)

        if (token != null) {
            bankAPI.transferir("Bearer $token", transferenciaRequest).enqueue(object : Callback<TransacaoResponseDTO> {
                override fun onResponse(
                    call: Call<TransacaoResponseDTO>,
                    response: Response<TransacaoResponseDTO>
                ) {
                    if (response.isSuccessful) {
                        val transacaoResponse = response.body()
                        if (transacaoResponse != null) {
                            mostrarDialogoSucesso(
                                "Transferência realizada com sucesso!\n" +
                                        "Número da Conta: ${transacaoResponse.contaDestino.numero}\n" +
                                        "Valor: ${transacaoResponse.valor}\n")                        } else {
                            Toast.makeText(
                                this@TransferirActivity,
                                "Resposta inesperada do servidor.",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        Toast.makeText(
                            this@TransferirActivity,
                            "Falha na transferência. Código: ${response.code()}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<TransacaoResponseDTO>, t: Throwable) {
                    Toast.makeText(
                        this@TransferirActivity,
                        "Erro na conexão: ${t.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
        } else {
            Toast.makeText(this, "Token não encontrado, faça login novamente.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun mostrarDialogoSucesso(mensagem: String) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Sucesso")
        builder.setMessage(mensagem)
        builder.setPositiveButton("OK") { dialog, _ ->
            dialog.dismiss() // Fecha o diálogo
        }
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }
}