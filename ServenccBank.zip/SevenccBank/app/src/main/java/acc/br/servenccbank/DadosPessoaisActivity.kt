package acc.br.servenccbank

import acc.br.servenccbank.datas.CadastroResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Context
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DadosPessoaisActivity : AppCompatActivity() {

    private lateinit var txtNome: TextView
    private lateinit var txtCpf: TextView
    private lateinit var txtDataNascimento: TextView
    private lateinit var txtTelefone: TextView
    private lateinit var txtEmail: TextView
    private lateinit var txtDataCadastro: TextView
    private lateinit var txtEndereco: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dados_pessoais_activity)

        txtNome = findViewById(R.id.txtNome)
        txtCpf = findViewById(R.id.txtCpf)
        txtDataNascimento = findViewById(R.id.txtDataNascimento)
        txtTelefone = findViewById(R.id.txtTelefone)
        txtEmail = findViewById(R.id.txtEmail)
        txtDataCadastro = findViewById(R.id.txtDataCadastro)
        txtEndereco = findViewById(R.id.txtEndereco)

        // Recuperar o token JWT das SharedPreferences
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val token = sharedPreferences.getString("JWT_TOKEN", null)

        if (token != null) {
            val apiService = APIClient.instance.create(BankAPI::class.java)
            val call = apiService.getPerfil("Bearer $token")

            call.enqueue(object : Callback<CadastroResponse> {
                override fun onResponse(call: Call<CadastroResponse>, response: Response<CadastroResponse>) {
                    if (response.isSuccessful) {
                        val perfil = response.body()
                        perfil?.let {
                            // Preenchendo as views com os dados retornados
                            txtNome.text = it.nome
                            txtCpf.text = it.cpf
                            txtDataNascimento.text = it.dataNascimento
                            txtTelefone.text = it.telefone
                            txtEmail.text = it.email
                            txtDataCadastro.text = it.dataCadastro
                            txtEndereco.text = "${it.endereco.rua}, ${it.endereco.numero} - ${it.endereco.bairro}, ${it.endereco.cidade} - ${it.endereco.estado}, ${it.endereco.pais}"
                        }
                    } else {
                        Toast.makeText(this@DadosPessoaisActivity, "Erro ao carregar dados: ${response.code()}", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<CadastroResponse>, t: Throwable) {
                    Toast.makeText(this@DadosPessoaisActivity, "Erro: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "Token não encontrado. Faça login novamente.", Toast.LENGTH_SHORT).show()
        }
    }
}
