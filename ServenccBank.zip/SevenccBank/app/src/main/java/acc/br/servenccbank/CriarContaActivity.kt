package acc.br.servenccbank

import acc.br.servenccbank.datas.conta.ContaRequest
import acc.br.servenccbank.datas.conta.ContaResponse
import acc.br.servenccbank.interfaces.BankAPI
import android.content.Context
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class CriarContaActivity : AppCompatActivity() {

    private lateinit var spinnerTipoConta: Spinner
    private lateinit var btnCriarConta: Button
    private lateinit var progressBar: ProgressBar
    private val numeroAgenciaFixo: Long = 25789

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.criar_conta_activity)

        spinnerTipoConta = findViewById(R.id.spinnerTipoConta)
        btnCriarConta = findViewById(R.id.btnCriarConta)
        progressBar = findViewById(R.id.progressBar)

        // Configurar o Spinner com opções
        val tiposConta = arrayOf("CORRENTE", "POUPANCA")
        spinnerTipoConta.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tiposConta)

        btnCriarConta.setOnClickListener {
            val tipoConta = spinnerTipoConta.selectedItem.toString()

            if (tipoConta.isNotEmpty()) {
                val tipoContaEnum = when (tipoConta) {
                    "CORRENTE" -> TipoConta.CORRENTE
                    "POUPANCA" -> TipoConta.POUPANCA
                    else -> null
                }

                if (tipoContaEnum != null) {
                    criarConta(tipoContaEnum)
                } else {
                    Toast.makeText(this, "Tipo de conta inválido", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Selecione o tipo de conta", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun criarConta(tipoConta: TipoConta) {
        progressBar.visibility = ProgressBar.VISIBLE
        btnCriarConta.isEnabled = false

        val apiService = APIClient.instance.create(BankAPI::class.java)
        val token = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            .getString("JWT_TOKEN", null) ?: ""

        val contaRequest = ContaRequest(numeroDaAgencia = numeroAgenciaFixo, tipo = tipoConta)
        val call = apiService.createConta("Bearer $token", contaRequest)

        call.enqueue(object : Callback<ContaResponse> {
            override fun onResponse(call: Call<ContaResponse>, response: Response<ContaResponse>) {
                progressBar.visibility = ProgressBar.GONE
                btnCriarConta.isEnabled = true

                if (response.isSuccessful) {
                    Toast.makeText(this@CriarContaActivity, "Conta criada com sucesso", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    val errorBody = response.errorBody()?.string()
                    Toast.makeText(this@CriarContaActivity, "Erro ao criar conta: ${response.code()} - $errorBody", Toast.LENGTH_LONG).show()
                    if (response.code() == 409) {
                        showAccountExistsDialog()
                    }
                }
            }

            override fun onFailure(call: Call<ContaResponse>, t: Throwable) {
                progressBar.visibility = ProgressBar.GONE
                btnCriarConta.isEnabled = true
                Toast.makeText(this@CriarContaActivity, "Erro: ${t.message}", Toast.LENGTH_LONG).show()
            }
        })
    }

    private fun showAccountExistsDialog() {
        AlertDialog.Builder(this)
            .setTitle("Conta Existente")
            .setMessage("Você já possui uma conta. Não é possível criar uma nova conta.")
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}
