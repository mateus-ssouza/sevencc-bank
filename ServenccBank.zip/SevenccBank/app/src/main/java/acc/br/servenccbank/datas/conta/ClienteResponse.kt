package acc.br.servenccbank.datas.conta

data class ClienteResponse(
    val nome : String,
    val cpf : String
)
