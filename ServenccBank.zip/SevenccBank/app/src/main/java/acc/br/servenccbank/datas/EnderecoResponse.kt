package acc.br.servenccbank.datas

data class EnderecoResponse(
    val cep: String,
    val rua: String,
    val numero: String,
    val bairro: String,
    val cidade: String,
    val estado: String,
    val pais: String
)
