package acc.br.servenccbank.datas.conta

data class AgenciaResponse(
    val nome : String,
    val numero: Long
)
