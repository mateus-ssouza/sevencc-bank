package acc.br.servenccbank.adapters

import acc.br.servenccbank.datas.conta.TransacoesContaResponse
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import acc.br.servenccbank.R

class ExtratoAdapter(context: Context, private val transacoes: List<TransacoesContaResponse>) :
    ArrayAdapter<TransacoesContaResponse>(context, 0, transacoes) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val transacao = getItem(position)
        val view = convertView ?: LayoutInflater.from(context).inflate(R.layout.item_extrato, parent, false)

        val txtValor: TextView = view.findViewById(R.id.txtValor)
        val txtTipo: TextView = view.findViewById(R.id.txtTipo)
        val txtData: TextView = view.findViewById(R.id.txtData)
        val txtContaDestino: TextView = view.findViewById(R.id.txtContaDestino)

        txtValor.text = transacao?.valor.toString()
        txtTipo.text = transacao?.tipo.toString()
        txtData.text = transacao?.dataTransacao

        txtContaDestino.text = transacao?.contaDestino?.clienteDestino?.nome ?: "N/A"

        return view
    }
}
