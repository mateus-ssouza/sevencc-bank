package acc.br.servenccbank

import acc.br.servenccbank.adapters.BigDecimalTypeAdapter
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.google.gson.GsonBuilder
import java.math.BigDecimal


object APIClient {
    private const val BASE_URL = "http://192.168.0.4:8080/"

    val instance: Retrofit by lazy {
        val gson = GsonBuilder()
            .registerTypeAdapter(BigDecimal::class.java, BigDecimalTypeAdapter())
            .create()

        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

}
